package demoqa;


import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment4 {

	public static void main(String[] args) throws InterruptedException  {

		System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// navigate to rediff.com
		driver.get("https://www.rediff.com/");

		driver.findElement(By.xpath("//a[@title='Already a user? Sign in']")).click();



		driver.navigate().to("https://mail.rediff.com/cgi-bin/login.cgi");
		driver.findElement(By.xpath("//input[@title]")).click();
		Thread.sleep(1000);

		driver.switchTo().alert().accept();

		driver.navigate().to("https://demoqa.com/browser-windows");

		String ParentwindowHandle = driver.getWindowHandle();

		//new tab
		driver.findElement(By.id("tabButton")).click();
		Thread.sleep(1000);
		driver.switchTo().window(ParentwindowHandle);

		//new window
		driver.findElement(By.id("windowButton")).click();
		Thread.sleep(1000);
		driver.switchTo().window(ParentwindowHandle);

		//new window message
		driver.findElement(By.id("messageWindowButton")).click();
		Thread.sleep(1000);
		driver.switchTo().window(ParentwindowHandle);

		Set<String> allWindowHandles = driver.getWindowHandles();
		System.out.println(driver.getWindowHandles());

		ArrayList<String>tabs =new ArrayList<String>(driver.getWindowHandles());
		System.out.println("no. of tabs : " + tabs.size());
		Thread.sleep(1000);
//tested successfully
		
		driver.quit();
	}


}
